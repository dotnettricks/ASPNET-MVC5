namespace DAL.Migrations
{
    using System;
    using System.Data.Entity;
    using System.Data.Entity.Migrations;
    using System.Linq;

    internal sealed class Configuration : DbMigrationsConfiguration<DAL.DatabaseContext>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = false;
        }

        protected override void Seed(DAL.DatabaseContext context)
        {
            //Category c1 = new Category { Name = "Books" };
            //Category c2 = new Category { Name = "Notepad" };

            //context.Categories.Add(c1);
            //context.Categories.Add(c2);
        }
    }
}
