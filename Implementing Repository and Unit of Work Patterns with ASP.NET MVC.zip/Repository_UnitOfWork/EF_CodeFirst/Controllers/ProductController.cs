﻿using BAL;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DomainModels;
using BAL.Interfaces;

namespace EF_CodeFirst.Controllers
{
    public class ProductController : Controller
    {
        IUnitOfWork db;

        public ProductController()
        {
            db = new UnitOfWork();
        }

        public ActionResult Index()
        {
            return View(db.Products.GetAll());
        }

        public ActionResult Create()
        {
            ViewBag.Categories = db.Categories.GetAll();
            return View();
        }

        [HttpPost]
        public ActionResult Create(Product item)
        {
            try
            {
                db.Products.Add(item);
                db.SaveChanges();

                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                ViewBag.Categories = db.Categories.GetAll();
                return View();
            }
        }

        public ActionResult Edit(int id)
        {
            ViewBag.Categories = db.Categories.GetAll();
            return View(db.Products.Get(id));
        }

        [HttpPost]
        public ActionResult Edit(Product item)
        {
            try
            {
                db.Products.Update(item);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                ViewBag.Categories = db.Categories.GetAll();
                return View();
            }
        }

        public ActionResult Delete(int id)
        {
            db.Products.Remove(id);
            db.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}