﻿using DAL;
using DomainModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BAL
{
    public interface ICategoryRepository : IRepository<Category>
    {

    }
}
