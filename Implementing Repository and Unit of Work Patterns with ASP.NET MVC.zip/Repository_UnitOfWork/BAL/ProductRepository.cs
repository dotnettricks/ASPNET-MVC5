﻿using DAL;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DomainModels;

namespace BAL
{
    public class ProductRepository : Repository<Product>, IProductRepository
    {
        public DatabaseContext context
        {
            get
            {
                return db as DatabaseContext;
            }
        }

        public ProductRepository(DatabaseContext _db)
            : base(_db)
        {

        }
                
        public IEnumerable<Product> GetProductsByCategory(int id)
        {
            return context.Products.Where(p => p.CategoryId == id).ToList();
        }
    }
}
