﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Mvc4_Multiple_Submit_Button.Models;

namespace Mvc4_Multiple_Submit_Button.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public RedirectResult Demo()
        {
            return Redirect("http://www.dotnet-tricks.com/Tutorial/mvc/cM1X161112-Handling-multiple-submit-buttons-on-the-same-form---MVC-Razor.html");
        }

        public ActionResult MultipleCommand()
        {
            return View();
        }

        [HttpPost]
        public ActionResult MultipleCommand(RegistrationModel mReg, string Command)
        {
            if (Command == "Save")
            {
                //TO DO : for Save button Click
            }
            else if (Command == "Submit")
            {
                //TO DO : for Submit button Click
            }
            else
            {
                //TO DO : for Cancel button Click

                return RedirectToAction("Index");
            }
            return View();
        }

        [HttpPost]
        public ActionResult MultipleButtonCancel()
        {
            //TO DO : for Cancel button Click

            return RedirectToAction("Index");
        }
    }
}
