﻿using System.Web;
using System.Web.Mvc;

namespace Mvc4_Multiple_Submit_Button
{
    public class FilterConfig
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new HandleErrorAttribute());
        }
    }
}