﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Mvc4_CustomWebGrid.Models;

namespace Mvc4_CustomWebGrid.Controllers
{
    public class HomeController : Controller
    {
        ModelServices mobjModel = new ModelServices();

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Demo()
        {
            Response.Redirect("http://www.dotnet-tricks.com/Tutorial/mvclist");
            return View();
        }

        public ActionResult WebGridCustomPaging(int page = 1, string sort = "custid", string sortDir = "ASC")
        {
            const int pageSize = 5;
            var totalRows = mobjModel.CountCustomer();

            bool Dir = sortDir.Equals("desc", StringComparison.CurrentCultureIgnoreCase) ? true : false;

            var customer = mobjModel.GetCustomerPage(page, pageSize, sort, Dir);
            var data = new PagedCustomerModel()
            {
                TotalRows = totalRows,
                PageSize = pageSize,
                Customer = customer
            };
            return View(data);
        }

    }
}
